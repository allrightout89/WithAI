-- WithAi 회원용 운동 설명을 관리자 설정과 연동하는 보완 SQL
-- 기존 테이블/회원/레슨/운동/식단 데이터는 삭제하거나 초기화하지 않습니다.
-- Supabase SQL Editor에서 이 파일의 내용을 한 번 실행하세요.

create or replace function public.withai_member_enter_by_last4(p_last4 text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_data jsonb;
  v_member jsonb;
  v_count integer;
  v_sessions jsonb;
  v_meals jsonb;
begin
  if p_last4 is null or p_last4 !~ '^[0-9]{4}$' then
    return jsonb_build_object('ok',false,'message','휴대폰 번호 뒷자리 숫자 4자리를 입력해 주세요.');
  end if;

  select data into v_data
  from public.withai_app_snapshots
  order by updated_at desc
  limit 1;

  if v_data is null then
    return jsonb_build_object('ok',false,'message','센터 클라우드 데이터가 준비되지 않았습니다. 센터에 문의해 주세요.');
  end if;

  select count(*), (array_agg(m.value))[1]
    into v_count, v_member
  from jsonb_array_elements(coalesce(v_data->'members','[]'::jsonb)) m(value)
  where right(regexp_replace(coalesce(m.value->>'phone',''),'[^0-9]','','g'),4) = p_last4
    and coalesce(m.value->>'status','') not in ('가입 대기','승인 대기','종료');

  if v_count = 0 then
    return jsonb_build_object('ok',false,'message','해당 번호로 승인된 회원을 찾을 수 없습니다. 가입 승인 여부를 확인하거나 센터에 문의해 주세요.');
  elsif v_count > 1 then
    return jsonb_build_object('ok',false,'message','동일한 휴대폰 번호 뒷자리 4자리를 사용하는 회원이 여러 명입니다. 안전을 위해 로그인을 중단했습니다. 센터에 문의해 주세요.');
  end if;

  select coalesce(jsonb_agg(x.value order by coalesce(x.value->>'date','') desc),'[]'::jsonb)
    into v_sessions
  from jsonb_array_elements(coalesce(v_data->'sessions','[]'::jsonb)) x(value)
  where coalesce(x.value->>'memberId',x.value->>'member_id','') = coalesce(v_member->>'id','');

  select coalesce(jsonb_agg(x.value order by coalesce(x.value->>'date','') desc),'[]'::jsonb)
    into v_meals
  from jsonb_array_elements(coalesce(v_data->'meals','[]'::jsonb)) x(value)
  where coalesce(x.value->>'memberId',x.value->>'member_id','') = coalesce(v_member->>'id','');

  return jsonb_build_object('ok',true,'member',v_member,'sessions',v_sessions,'meals',v_meals);
end;
$$;

create or replace function public.withai_member_get_portal(p_token text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_owner uuid; v_member_id text; v_data jsonb; v_member jsonb;
  v_sessions jsonb; v_meals jsonb; v_exercises jsonb;
begin
  select owner_user_id,member_id into v_owner,v_member_id
  from public.withai_member_portal_tokens
  where token=p_token and expires_at>now();
  if v_owner is null then return jsonb_build_object('ok',false,'message','회원 로그인 정보가 만료되었습니다. 다시 로그인해 주세요.'); end if;
  select data into v_data from public.withai_app_snapshots where owner_user_id=v_owner;
  if v_data is null then return jsonb_build_object('ok',false,'message','회원 데이터를 찾을 수 없습니다.'); end if;
  select e.value into v_member from jsonb_array_elements(coalesce(v_data->'members','[]'::jsonb)) e(value) where e.value->>'id'=v_member_id limit 1;
  if v_member is null then return jsonb_build_object('ok',false,'message','회원 정보가 삭제되었거나 이용할 수 없습니다. 센터에 문의해 주세요.'); end if;
  select coalesce(jsonb_agg(x.value order by coalesce(x.value->>'date','') desc),'[]'::jsonb) into v_sessions from jsonb_array_elements(coalesce(v_data->'sessions','[]'::jsonb)) x(value) where coalesce(x.value->>'memberId',x.value->>'member_id','')=v_member_id;
  select coalesce(jsonb_agg(x.value order by coalesce(x.value->>'date','') desc),'[]'::jsonb) into v_meals from jsonb_array_elements(coalesce(v_data->'meals','[]'::jsonb)) x(value) where coalesce(x.value->>'memberId',x.value->>'member_id','')=v_member_id;
  select coalesce(jsonb_agg(x.value order by coalesce(x.value->>'date','') desc),'[]'::jsonb) into v_exercises from jsonb_array_elements(coalesce(v_data->'memberExercises','[]'::jsonb)) x(value) where coalesce(x.value->>'memberId',x.value->>'member_id','')=v_member_id;
  return jsonb_build_object('ok',true,'token',p_token,'member',v_member,'sessions',v_sessions,'meals',v_meals,'memberExercises',v_exercises,'exerciseGuides',coalesce(v_data->'memberExerciseGuides','[]'::jsonb));
end;
$$;

-- 함수 권한은 기존 설정을 유지합니다. 아래 GRANT는 해당 함수 호출 권한을 명시적으로 보장합니다.
revoke all on function public.withai_member_enter_by_last4(text) from public;
grant execute on function public.withai_member_enter_by_last4(text) to anon, authenticated;
revoke all on function public.withai_member_get_portal(text) from public;
grant execute on function public.withai_member_get_portal(text) to anon, authenticated;
